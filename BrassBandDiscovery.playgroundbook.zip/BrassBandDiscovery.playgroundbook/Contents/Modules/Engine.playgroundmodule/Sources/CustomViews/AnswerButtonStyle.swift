//
//  CustomButton.swift
//  BookCore
//
//  Created by Sascha Sallès on 19/04/2021.
//

import SwiftUI

struct AnswerButtonStyle: ButtonStyle {
  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .padding(10)
      .font(Font.system(size: 20, weight: .regular, design: .rounded))
      .background(Color(.systemTeal).cornerRadius(10))
      .foregroundColor(.white)
      .scaleEffect(configuration.isPressed ? 1.1 : 1)
      .animation(.easeOut(duration: 0.2))
  }
}

