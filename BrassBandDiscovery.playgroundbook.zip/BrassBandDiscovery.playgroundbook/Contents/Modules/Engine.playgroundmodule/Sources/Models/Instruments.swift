//
//  Instruments.swift
//  BookCore
//
//  Created by Sascha Sallès on 13/04/2021.
//

import Foundation
import SwiftUI
import AVFoundation

class Instrument: Identifiable, ObservableObject {
  @Published var isHidden: Bool = true
  @Published var isMuted: Bool = false
  var id: UUID = UUID()
  var name: String
  var nodeName: String
  var description: String
  var songURL: String
  var compoURL: String? = nil
  var usage: String
  var creationDate: Date? = nil
  var origin: String
  var soundType: String
  var isBouncing: Bool = false
  var longMusicPlayer: AVAudioPlayer? = nil

  convenience init(name: String, nodeName: String) {
    self.init(name: name, nodeName: nodeName, description: "", songURL: "", compoURL: nil, usage: "", creationDate: nil, origin: "", soundType: "")
  }

  init(name: String, nodeName: String, description: String, songURL: String, compoURL: String?, usage: String, creationDate: Date?, origin: String, soundType: String) {
    self.name = name
    self.nodeName = nodeName
    self.description = description
    self.songURL = songURL
    self.compoURL = compoURL
    self.usage = usage
    self.creationDate = creationDate
    self.origin = origin
    self.soundType = soundType
  }
}





var instruments = [
  Instrument(name: "All", nodeName: "All"),
  Instrument(name: "Trumpet",
             nodeName: "Trumpet",
             description: "The trumpet is a brass instrument commonly used in classical and jazz ensembles.",
             songURL: "Trumpet",
             compoURL: "compo_trumpet",
             usage: "Melodic section",
             creationDate: nil,
             origin: "Trumpet-like instruments have historically been used as signalling devices in battles ⚔️, with examples dating back to at least 1500 BCE.",
             soundType: "High frequences"
  ),
  Instrument(name: "Trombone",
             nodeName: "Trombone",
             description: "The Trombone is a brass used in a multitude of musical styles",
             songURL: "Trombone",
             compoURL: "compo_trombone",
             usage: "Melodic section",
             creationDate: nil,
             origin: "The trombone is descended from the sackbut, and was originally used in the military.",
             soundType: "Medium/Low frequences"
  ),
  Instrument(name: "Tenor Saxophone",
             nodeName: "TenorSax",
             description: "The saxophone is a family of woodwind instruments usually made of brass and played with a single-reed mouthpiece",
             songURL: "TenorSax",
             compoURL: "compo_sax",
             usage: "Melodic section",
             creationDate: Date("1846"),
             origin: "Designed and constructed by Adolphe Sax 🇫🇷",
             soundType: "Medium frequences"
  ),
  Instrument(name: "Bass Drum",
             nodeName: "BassDrum",
             description: "Percussion instrument producing a large drum that produces a note of low definite or indefinite pitch",
             songURL: "BassDrum",
             compoURL: "compo_kick",
             usage: "Rhythm section",
             creationDate: nil,
             origin: " The earliest known predecessor to the bass drum was the Turkish davul, a cylindrical drum that featured two thin heads.",
             soundType: "Low frequences"),
  Instrument(name: "Cymbal",
             nodeName: "RideCymbal",
             description: "Cymbals consist of thin, normally round plates of various alloys. The sound varies varies according to the zone struck",
             songURL: "RideCymbal",
             compoURL: "compo_cymbal",
             usage: "Rhythm section",
             creationDate: nil,
             origin: "Cymbals come from ancient times. Paintings from ancient Greece represent them",
             soundType: "High frequences"),
  Instrument(name: "Snare Drum",
             nodeName: "SnareDrum",
             description: "Percussion instrument producing a sharp sound, it's the central peace of a drum set. Can be played with sticks, brushes or fingers",
             songURL: "SnareDrum",
             compoURL: "compo_snare",
             usage: "Rhythm section",
             creationDate: nil,
             origin: "🏰 Unknown, descended from a medieval drum called the tabor",
             soundType: "Medium/High frequences"),
  Instrument(name: "Sousaphone",
             nodeName: "Sousaphone",
             description: "The sousaphone was designed to be easier to play than the concert tuba while standing or marching",
             songURL: "Sousaphone",
             compoURL: "compo_sousaphone",
             usage: "Rhythm section",
             creationDate: Date("1893"),
             origin: "Created and designed by James Welsh Pepper",
             soundType: "Low frequences")
]
