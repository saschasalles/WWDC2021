//
//  AppState.swift
//  BookCore
//
//  Created by Sascha Sallès on 10/04/2021.
//

import Foundation

enum TrackingState: Int16 {
    case detectSurface
    case pointAtSurface
    case tapToStart
    case started
}
