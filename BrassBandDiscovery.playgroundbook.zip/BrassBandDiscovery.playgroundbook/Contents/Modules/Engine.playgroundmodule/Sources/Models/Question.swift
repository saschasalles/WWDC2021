//
//  Question.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import AVFoundation

struct Question: Identifiable {
  var id: UUID = UUID()
  var title: String
  var audioPath: String?
  var answers: [Answer]
  var goodAnswer: Answer
  var isAnswered: Bool = false

  init(title: String, audioPath: String, answers: [Answer], goodAnswer: Answer) {
    self.title = title
    self.answers = answers
    self.audioPath = audioPath
    self.goodAnswer = goodAnswer
  }

  init(title: String, answers: [Answer], goodAnswer: Answer) {
    self.title = title
    self.answers = answers
    self.goodAnswer = goodAnswer
    self.audioPath = nil
  }

}


struct Answer: Identifiable {
  var id: UUID = UUID()
  var title: String
}


class QuizzViewModel: ObservableObject {
  @Published var questions: [Question]
  @Published var goodAnswers = 0
  

  init() {
    self.questions = [
      Question(title: "Who is the creator of the Sousaphone?",
               answers: [
                         Answer(title: "Adolph Sax"),
                         Answer(title: "Antonio Stradivari"),
                         Answer(title: "Leo Fender"),
                         Answer(title: "James Welsh Pepper"),
               ],
               goodAnswer: Answer(title: "James Welsh Pepper")),
      Question(title: "Is the saxophone part of the rhythm section?",
               answers: [
                         Answer(title: "Yes"),
                         Answer(title: "No"),
               ],
               goodAnswer: Answer(title: "No")),
      Question(title: "Is the trumpet played with a mouthpiece?",
               answers: [
                         Answer(title: "Yes"),
                         Answer(title: "No"),

               ],
               goodAnswer: Answer(title: "Yes")),
      Question(title: "Which instrument sound is it ?",
               audioPath: "Trombone",
               answers: [
                         Answer(title: "Tenor Saxophone"),
                         Answer(title: "Trombone"),
                         Answer(title: "Sousaphone"),
                         Answer(title: "Bass Drum"),
               ],
               goodAnswer: Answer(title: "Trombone")),
      Question(title: "The cymbals date back to :",
               answers: [
                         Answer(title: "Ancient Greece"),
                         Answer(title: "Viking Age"),
                         Answer(title: "Ancient Rome"),
                         Answer(title: "Contemporary Period"),
               ],
               goodAnswer: Answer(title: "Ancient Greece")),
    ]
  }
}
