//
//  AudioManager.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import AVFoundation

class AudioManager: NSObject, AVAudioPlayerDelegate {

  static let shared = AudioManager()

  private override init() { }

  var players: [URL: AVAudioPlayer] = [:]
  var duplicatePlayers: [AVAudioPlayer] = []
  var lastSoundFileURL: URL?

  func playSound(withName soundFileName: String) {

    guard let bundle = Bundle.main.path(forResource: soundFileName, ofType: "mp3") else { return }
    let soundFileNameURL = URL(fileURLWithPath: bundle)
    lastSoundFileURL = soundFileNameURL

    if let player = players[soundFileNameURL] {
      if !player.isPlaying {
        player.prepareToPlay()
        player.play()
      } else {
        do {
          let duplicatePlayer = try AVAudioPlayer(contentsOf: soundFileNameURL)

          duplicatePlayer.delegate = self
          duplicatePlayers.append(duplicatePlayer)
          duplicatePlayer.prepareToPlay()
          duplicatePlayer.play()
        } catch {
          print(error.localizedDescription)
        }

      }
    } else {
      do {
        let player = try AVAudioPlayer(contentsOf: soundFileNameURL)
        players[soundFileNameURL] = player
        player.prepareToPlay()
        player.play()
      } catch {
        print(error.localizedDescription)
      }
    }

  }


  func playSounds(soundFileNames: String...) {
    for soundFileName in soundFileNames {
      playSound(withName: soundFileName)
    }
  }

  func playSounds(soundFileNames: [String]) {
    for soundFileName in soundFileNames {
      playSound(withName: soundFileName)
    }
  }


  func playSounds(soundFileNames: [String], withDelay: Double) {
    for (index, soundFileName) in soundFileNames.enumerated() {
      let delay = withDelay * Double(index)
      let _ = Timer.scheduledTimer(timeInterval: delay, target: self, selector: #selector(playSoundNotification(_:)), userInfo: ["fileName": soundFileName], repeats: false)
    }
  }

  @objc func playSoundNotification(_ notification: NSNotification) {
    if let soundFileName = notification.userInfo?["fileName"] as? String {
      playSound(withName: soundFileName)
    }
  }
}
