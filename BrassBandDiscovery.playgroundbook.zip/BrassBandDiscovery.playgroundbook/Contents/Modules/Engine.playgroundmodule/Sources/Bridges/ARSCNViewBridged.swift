//
//  test.swift
//  BookCore
//
//  Created by Sascha Sallès on 10/04/2021.
//

import Foundation
import SwiftUI
import ARKit


struct ARSCNViewBridged: UIViewRepresentable {
  public var sceneView: ARSCNView

  public init(sceneView: ARSCNView) {
    self.sceneView = sceneView
  }

  public func makeUIView(context: Context) -> ARSCNView {
    return sceneView
  }

  public func updateUIView(_ uiView: ARSCNView, context: Context) { }
}
