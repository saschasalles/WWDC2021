//
//  ARSCNViewController.swift
//  BookCore
//
//  Created by Sascha Sallès on 16/04/2021.
//

import Foundation
import ARKit
import UIKit
import SwiftUI


public class ARSCNViewControllerSingleSound: UIViewController, ObservableObject {

  public static var shared = ARSCNViewControllerSingleSound()

  var sceneView: ARSCNView {
    return self.view as! ARSCNView
  }

  @Published var statusText: String = ""
  @Published var focusPoint: CGPoint!
  @Published var instrumentsNode: SCNNode!
  @Published var screenSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
  @Published var showStatistics = false
  @Published var showInfoView = false
  @Published var currentInstrument = instruments[0]
  private var trackingStatus: String = ""
  private var statusMessage: String = ""
  private(set) var trackingState: TrackingState = .detectSurface

  private var focusNode: SCNNode!


  public override func loadView() {
    self.view = ARSCNView(frame: .init(x: 0, y: 0, width: screenSize.width, height: screenSize.height))
  }

  public override func viewDidLoad() {
    super.viewDidLoad()

    self.initScene()
    self.initCoachingOverlayView()
    self.initARSession()
    self.initFocusNode()
  }

  public override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
  }

  public override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
  }

  public override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()

  }


// MARK: - Launch Tap Recognizer

  func startTap() {
    guard trackingState == .tapToStart else { return }
    fadeIn(forNode: self.instrumentsNode)
    fadeOut(forNode: self.focusNode)

    self.instrumentsNode.position = self.focusNode.position
    trackingState = .started
  }

// MARK: - AR Management

  func initARSession() {
    guard ARWorldTrackingConfiguration.isSupported else {
      print("AR World Tracking Not Supported on your device")
      return
    }

    let config = ARWorldTrackingConfiguration()
    config.worldAlignment = .gravity
    config.providesAudioData = false
    config.planeDetection = .horizontal
    config.isLightEstimationEnabled = true

    config.environmentTexturing = .automatic
    self.sceneView.session.run(config)
  }

  func resetARSession() {
    let config = self.sceneView.session.configuration as! ARWorldTrackingConfiguration
    config.planeDetection = .horizontal
    self.sceneView.session.run(config, options: [.resetTracking, .removeExistingAnchors])
    self.instrumentsNode.isHidden = true
  }


  // MARK: - Tracking State Management

  func updateStatus() {
    switch trackingState {
    case .detectSurface:
      statusMessage = "Searching for a floor or a plane surface 🔎"
    case .pointAtSurface:
      statusMessage = "Please point at designated surface 🤳"
    case .tapToStart:
      statusMessage = "Tap to start ☝️"
    case .started:
      statusMessage = "Tap an instrument to ear sound 🔊 & see info"
    }

    self.statusText = trackingStatus != "" ? "\(trackingStatus)" : "\(statusMessage)"
  }


  func startTracking() {
    DispatchQueue.main.async {
      self.focusNode.isHidden = true
      self.instrumentsNode.isHidden = true
      self.trackingState = .detectSurface
    }

  }

  func resetTracking() {
    DispatchQueue.main.async {
      self.instrumentsNode.isHidden = true
      self.resetARSession()
      self.trackingState = .detectSurface
    }
  }

  // MARK: - Scene Management

  func initScene() {
    let scene = SCNScene()

    sceneView.scene = scene
    sceneView.delegate = self
    sceneView.showsStatistics = false

    // Absolutely needed due complex 3D Assets

    let defaultScaleFactor = sceneView.contentScaleFactor
    sceneView.contentScaleFactor = 0.60 * defaultScaleFactor

    self.sceneView.debugOptions = [.showFeaturePoints]
    self.sceneView.antialiasingMode = .multisampling4X
    let completeScene = SCNScene(named: "3DAssets.scnassets/CompleteScene.scn")!

    instrumentsNode = completeScene.rootNode.childNode(
      withName: "Instruments", recursively: false)!
    instrumentsNode.isHidden = true
    sceneView.scene.rootNode.addChildNode(instrumentsNode)
  }

  func toggleStatistics() {
    sceneView.showsStatistics.toggle()
  }

  // MARK: - InstrumentsNode Management

  func selectInstrument(withName name: String, identifier id: UUID? = nil) {
    instrumentsNode.isHidden = false
    let instrumentsChildNodes = instrumentsNode.childNodes

    if name == "All" {
      instrumentsChildNodes.forEach { node in
        node.isHidden = false
      }
    } else {
      for node in instrumentsChildNodes where node.name != name && node.name != "touch_\(name)" { node.isHidden = true }

      guard let displayNode = instrumentsNode.childNode(withName: name, recursively: false) else { return }

      guard displayNode.isHidden else { return }
      displayNode.isHidden.toggle()

      guard let instrument = instruments.first(where: { $0.id == id }) else { return }
      instrument.isHidden.toggle()
      for ins in instruments where ins.id != instrument.id { ins.isHidden = false }
    }
  }

  func touchInstrument(atLocation location: CGPoint) {
    DispatchQueue.main.async {
      if let hit = self.sceneView.hitTest(location, options: nil).first {
        for instrument in instruments {
          if hit.node.name == "touch_\(instrument.nodeName)" {
            self.currentInstrument = instrument
            self.showInfoView = true
            if let tappedInstrumentNode = self.instrumentsNode.childNode(withName: instrument.nodeName, recursively: false) {
              self.bounce(forNodes: tappedInstrumentNode, hit.node)


              AudioManager.shared.playSound(withName: instrument.songURL)
//                self.currentInstrument = instruments[0]
//                tappedInstrumentNode.removeAnimation(forKey: "bounce")
//                hit.node.removeAnimation(forKey: "bounce")
            }
          }
        }
      }
    }
  }


  // MARK: - Animations & Transitions

  func fadeIn(forNode node: SCNNode) {
    node.opacity = 1
    node.isHidden = false
    node.runAction(SCNAction.fadeIn(duration: 2.0))
  }

  func fadeOut(forNode node: SCNNode) {
    node.opacity = 0
    node.isHidden = true
    node.runAction(SCNAction.fadeOut(duration: 2.0))
  }


  func bounce(forNodes nodes: SCNNode..., infinite: Bool = false) {
    let bounce = CABasicAnimation(keyPath: "position.y")
    nodes.forEach { node in
      let origin = node.position.y
      let target = origin + 0.1

      bounce.duration = 0.3
      bounce.fromValue = origin
      bounce.toValue = target
      bounce.repeatCount = infinite ? .infinity : 1
      bounce.autoreverses = true
      node.addAnimation(bounce, forKey: "bounce")
    }
  }


  // MARK: - Focus Node Management

  func initFocusNode() {
    let focusScene = SCNScene(named: "3DAssets.scnassets/FocusScene.scn")!
    focusNode = focusScene.rootNode.childNode(withName: "Focus", recursively: false)!
    focusNode.isHidden = true
    self.sceneView.scene.rootNode.addChildNode(focusNode)

    self.focusPoint = CGPoint(x: self.sceneView.center.x,
                              y: self.sceneView.center.y)

    NotificationCenter.default.addObserver(
      self,
      selector: #selector(self.orientationChanged),
      name: UIDevice.orientationDidChangeNotification,
      object: nil)
  }

  func updateFocusNode() {
    guard trackingState != .started else {
      focusNode.isHidden = true
      return
    }

    if let query = self.sceneView.raycastQuery(
        from: self.focusPoint,
        allowing: .estimatedPlane,
        alignment: .horizontal) {

      let results = self.sceneView.session.raycast(query)

      if results.count == 1 {
        if let match = results.first {
          let worldTransform = match.worldTransform
          self.focusNode.position = SCNVector3(
            x: worldTransform.columns.3.x,
            y: worldTransform.columns.3.y,
            z: worldTransform.columns.3.z)
          self.trackingState = .tapToStart
          focusNode.isHidden = false
        }
      } else {
        self.trackingState = .pointAtSurface
        focusNode.isHidden = true
      }
    }
  }

  // MARK: - Position and Orientation

  @objc func orientationChanged() {
    focusPoint = CGPoint(x: sceneView.center.x, y: sceneView.center.y)
  }
}


// MARK: - ARSession

extension ARSCNViewControllerSingleSound {
  public func sessionWasInterrupted(_ session: ARSession) {
    self.trackingStatus = "AR Session interruption interrupted"
  }

  public func sessionInterruptionEnded(_ session: ARSession) {
    trackingStatus = "AR Session was ended"
  }

  public func session(_ session: ARSession, didFailWithError error: Error) {
    trackingStatus = "AR Session Failure: \(error)"
  }

  public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
    switch camera.trackingState {
    case .notAvailable:
      trackingStatus = "Tracking: not available"
    case .normal:
      trackingStatus = ""
    case .limited(let reason):
      switch reason {
      case .excessiveMotion:
        trackingStatus = "Tracking: Excessive motion..."
      case .insufficientFeatures:
        trackingStatus = "Tracking: Limited, Insufficient features"
      case .relocalizing:
        trackingStatus = "Tracking: Relocalizing..."
      case .initializing:
        trackingStatus = "Tracking: Initializing..."
      @unknown default:
        trackingStatus = "Tracking: Unknown"
      }
    }
  }
}

// MARK: - ARSCNViewDelegate

extension ARSCNViewControllerSingleSound: ARSCNViewDelegate {
  @objc public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
    DispatchQueue.main.async {
      self.updateStatus()
      self.updateFocusNode()
    }
  }
}


// MARK: - ARCoachingOverlayViewDelegate
extension ARSCNViewControllerSingleSound: ARCoachingOverlayViewDelegate {

  public func coachingOverlayViewWillActivate(_ coachingOverlayView: ARCoachingOverlayView) { }

  public func coachingOverlayViewDidDeactivate(_ coachingOverlayView: ARCoachingOverlayView) {
    self.startTracking()
  }

  public func coachingOverlayViewDidRequestSessionReset(_ coachingOverlayView: ARCoachingOverlayView) {
    self.resetTracking()
  }


  func initCoachingOverlayView() {
    let coachingOverlay = ARCoachingOverlayView()
    coachingOverlay.session = self.sceneView.session
    coachingOverlay.delegate = self
    coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
    coachingOverlay.activatesAutomatically = true
    coachingOverlay.goal = .horizontalPlane
    self.sceneView.addSubview(coachingOverlay)

    NSLayoutConstraint.activate([
      NSLayoutConstraint(item: coachingOverlay, attribute: .top, relatedBy: .equal, toItem: self.sceneView, attribute: .top, multiplier: 1, constant: 0),
      NSLayoutConstraint(item: coachingOverlay, attribute: .bottom, relatedBy: .equal, toItem: self.sceneView, attribute: .bottom, multiplier: 1, constant: 0),
      NSLayoutConstraint(item: coachingOverlay, attribute: .leading, relatedBy: .equal, toItem: self.sceneView, attribute: .leading, multiplier: 1, constant: 0),
      NSLayoutConstraint(item: coachingOverlay, attribute: .trailing, relatedBy: .equal, toItem: self.sceneView, attribute: .trailing, multiplier: 1, constant: 0),
    ])
  }
}
