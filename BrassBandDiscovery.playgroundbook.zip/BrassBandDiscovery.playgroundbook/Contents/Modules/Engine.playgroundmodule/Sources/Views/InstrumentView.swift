//
//  InstrumentView.swift
//  BookCore
//
//  Created by Sascha Sallès on 09/04/2021.
//

import SwiftUI
import ARKit
import PlaygroundSupport


public struct InstrumentView: View {
  @EnvironmentObject var ARSCNController: ARSCNViewControllerSingleSound
  @State private var expandInfoMenu: Bool = false

  public init() { }

  public var body: some View {

    ARSCNViewBridged(sceneView: ARSCNController.sceneView)
      .ignoresSafeArea()
      // Act like a tap gesture
      .gesture(
      DragGesture(minimumDistance: 0)
        .onEnded({ value in
        if ARSCNController.trackingState == .tapToStart {
          ARSCNController.startTap()
        } else if ARSCNController.trackingState == .started {
          ARSCNController.touchInstrument(atLocation: value.location)
        }
      }))
      // When rotations or resizes of the view occur, .overlay performs better than the ZStack & .background
      .overlay(
      VStack(alignment: .center, spacing: 0) {
        HStack(alignment: .top) {
          SingleSoundSettingsView(ARSCNController: ARSCNController, expandMenu: $expandInfoMenu)
            .frame(width: 150)
          Spacer()
          BlurView(style: .systemUltraThinMaterialDark)
            .overlay(
            HStack {
              Text(ARSCNController.statusText)
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                .animation(.easeIn)
            }
          )
            .frame(height: 46)
            .cornerRadius(10)
        }.padding(10)

        Spacer()

        if (ARSCNController.trackingState == .started) {
          InstrumentSelectorView()
            .frame(minWidth: 400, maxWidth: 930, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)

          if ARSCNController.showInfoView {
            InstrumentInfoView(ARSCNController: ARSCNController)
              .padding(.horizontal, 30)
              .animation(.spring())
          }
        }
      }.transition(.opacity)
      , alignment: .top)


  }
}

