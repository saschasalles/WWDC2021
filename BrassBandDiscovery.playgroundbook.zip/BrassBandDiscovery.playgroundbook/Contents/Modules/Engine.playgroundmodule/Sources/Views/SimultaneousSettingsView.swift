//
//  SimultaneousSettingsView.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import SwiftUI

struct SimultaneousSettingsView: View {
  @ObservedObject var ARSCNController: ARSCNViewControllerSimultaneous
  @Binding var expandMenu: Bool
  @State private var statisticsOn: Bool = false
  var foreverAnimation: Animation {
      Animation.linear(duration: 2.0)
          .repeatForever(autoreverses: false)
  }

  var body: some View {

    VStack(spacing: 5) {
      HStack {
        Image(systemName: "arkit")
          .font(.title3)
          .foregroundColor(.white)
          .rotationEffect(Angle(degrees: self.expandMenu ? 360 : 0.0))
          .animation(self.expandMenu ? foreverAnimation : .default)

        Text("Settings")
          .font(.headline)
          .bold()
          .foregroundColor(.white)
        Image(systemName: expandMenu ? "chevron.up" : "chevron.down")
          .font(.callout)
          .foregroundColor(.white)
      }.onTapGesture {
        self.expandMenu.toggle()
      }

      if expandMenu {
        VStack(alignment: .leading) {
          Text("Height: " + String(format: "%.2f", ARSCNController.sceneView.frame.height))
            .font(.subheadline)
            .foregroundColor(.white)
          Divider()
          Text("Width: " + String(format: "%.2f", ARSCNController.sceneView.frame.width))
            .font(.subheadline)
            .foregroundColor(.white)
          Divider()

          Button(action: {
            ARSCNController.resetARSession()
            self.expandMenu.toggle()
          }, label: {
            Text("Reset AR Session")
              .font(.subheadline)
              .foregroundColor(Color(.systemTeal))
          })
          Divider()
          Toggle(isOn: $statisticsOn) {
            Text("Scene Statistics")
              .font(.subheadline)
              .foregroundColor(.white)
          }
            .onChange(of: statisticsOn, perform: { value in
              ARSCNController.toggleStatistics()
          })
        }
      }
    }
      .padding(10)
      .background(BlurView(style: .systemUltraThinMaterialDark))
      .cornerRadius(10)
      .animation(.spring())
  }
}

