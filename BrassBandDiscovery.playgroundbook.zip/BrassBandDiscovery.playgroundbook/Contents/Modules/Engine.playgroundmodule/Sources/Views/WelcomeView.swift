//
//  File.swift
//  BookCore
//
//  Created by Sascha Sallès on 09/04/2021.
//

import Foundation
import SwiftUI

public struct WelcomeView: View {
  public init() { }


  public var body: some View {
    VStack {
      LinearGradient(gradient:
        Gradient(
          colors: [Color(.systemYellow), Color(.orange), Color(.purple)]),
          startPoint: .leading,
          endPoint: .trailing)
        .mask(
          Text("Brass Band Discovery")
            .font(.largeTitle)
            .bold())
        .frame(height: 70)

      
      Spacer()
    }
  }
}
