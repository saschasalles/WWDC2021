//
//  QuizzView.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import SwiftUI

public struct QuizzView: View {
  public init() { }
  @ObservedObject var quizzVM = QuizzViewModel()
  @State private var currentIndex = 0
  @State private var showStatusView = false
  @State private var wasGood = false


  private var gridLayout = [
    GridItem(.flexible()),
    GridItem(.flexible())
  ]

  public var body: some View {
    VStack(alignment: .center, spacing: 60) {
      LinearGradient(gradient:
        Gradient(colors: [Color(.systemYellow), Color(.orange), Color(.purple)]),
      startPoint: .leading, endPoint: .trailing)
        .mask(Text("Check your skills 🎷")
        .font(.largeTitle)
        .bold())
        .frame(height: 100, alignment: .center)
        .padding(.top, 20)
      Spacer()

      if showStatusView  {
        AdaptativeResultView(isGood: wasGood)
          .transition(.opacity)
          .onAppear(perform: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                  self.showStatusView = false
              })
          })
      }

      Text("\(quizzVM.goodAnswers)/\(quizzVM.questions.count)")
        .font(Font.system(size: 80, weight: .heavy, design: .rounded))


      

      if currentIndex < quizzVM.questions.count {
        VStack(spacing: 40) {
          HStack {
            Text(quizzVM.questions[currentIndex].title)
              .font(.title2)
              .fontWeight(.semibold)
              .foregroundColor(Color(.systemIndigo))
            if let audioPath = quizzVM.questions[currentIndex].audioPath {

              Button {
                AudioManager.shared.playSound(withName: audioPath)
              } label: {
                Image(systemName: "play.circle.fill")
                  .font(.title)
                  .foregroundColor(.gray)
              }
            }
          }

          LazyVGrid(columns: gridLayout, spacing: 30) {
            ForEach(quizzVM.questions[currentIndex].answers) { answer in
              Button {
                if answer.title == quizzVM.questions[currentIndex].goodAnswer.title {
                  quizzVM.goodAnswers += 1
                  self.wasGood = true
                } else {
                  self.wasGood = false
                }
                showStatusView = true
                currentIndex += 1
              } label: {
                Text(answer.title)
                  .frame(minWidth: 0, maxWidth: .infinity, minHeight: 50)

              }.buttonStyle(AnswerButtonStyle())
                .padding(.horizontal, 20)
            }
          }.frame(minWidth: 300, idealWidth: 500, maxWidth: 700)
        }
      } else {
        Text("Game over")
        Button {
          currentIndex = 0
          quizzVM.goodAnswers = 0
        } label: {
          HStack {
            Image(systemName: "arrowshape.turn.up.backward.circle.fill")
              .font(.title)
              .foregroundColor(Color(.systemIndigo))
            Text("Restart the Quizz")
              .foregroundColor(Color(.systemIndigo))
          }
        }
      }
      Spacer()
    }.animation(.linear)
  }
}
