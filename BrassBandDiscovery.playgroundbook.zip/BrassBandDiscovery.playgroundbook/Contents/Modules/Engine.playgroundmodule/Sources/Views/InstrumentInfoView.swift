//
//  InstrumentInfoView.swift
//  BookCore
//
//  Created by Sascha Sallès on 15/04/2021.
//

import Foundation
import SwiftUI

struct InstrumentInfoView: View {
  @ObservedObject var ARSCNController: ARSCNViewControllerSingleSound
  let dateFormatter: DateFormatter

  init(ARSCNController: ARSCNViewControllerSingleSound) {
    self.ARSCNController = ARSCNController
      dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "yyyy"
  }


  var body: some View {
    VStack(alignment: .leading) {
      HStack {
      Text(ARSCNController.currentInstrument.name)
        .foregroundColor(.white)
        .font(.title)
        Spacer()
        Button(action: {
          ARSCNController.showInfoView = false
        }, label: {
          Image(systemName: "xmark.circle.fill")
            .foregroundColor(.white)
            .font(.title)
        })
      }
      if let creationDate = ARSCNController.currentInstrument.creationDate {
        HStack {
        Text("Creation Year:")
          .font(.subheadline)
          .bold()
          .foregroundColor(.white)
        Text(creationDate, formatter: self.dateFormatter)
          .font(.subheadline)
          .foregroundColor(.white)
        }
      }

      Text("Description: \(ARSCNController.currentInstrument.description)")
        .font(.subheadline)
        .foregroundColor(.white)

      Text("Origin: \(ARSCNController.currentInstrument.origin)")
        .font(.subheadline)
        .foregroundColor(.white)

      Text("Sound Type: \(ARSCNController.currentInstrument.soundType)")
        .font(.subheadline)
        .foregroundColor(.white)


      Text("Usage: \(ARSCNController.currentInstrument.usage)")
        .font(.subheadline)
        .foregroundColor(.white)

    }
      .padding()
      .background(BlurView(style: .systemThinMaterialDark))
      .cornerRadius(18)
  }

}
