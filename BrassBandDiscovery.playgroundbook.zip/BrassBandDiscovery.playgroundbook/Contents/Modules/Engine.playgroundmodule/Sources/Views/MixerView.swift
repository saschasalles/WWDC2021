//
//  MixerView.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import SwiftUI
import Combine


struct MixerView: View {

  @ObservedObject var ARSCNSimultaneous: ARSCNViewControllerSimultaneous
  var targetInstrument = instruments[1]
  var body: some View {
    VStack(alignment: .leading) {
      HStack {

        Button(action: {

          self.targetInstrument.longMusicPlayer!.isPlaying ? ARSCNSimultaneous.stopPlaying(): ARSCNSimultaneous.startPlaying()
        }, label: {

          Label {
            Text(self.targetInstrument.longMusicPlayer!.isPlaying ? "Pause" : "Play")
              .foregroundColor(.white)

          } icon: {
            Image(systemName: self.targetInstrument.longMusicPlayer!.isPlaying ? "pause.circle.fill" : "play.circle.fill")
              .foregroundColor(.white)

          }
        })
      }
        .padding()


      VStack {
        HStack {
          ForEach(instruments) { instrument in
            if let audioPlayer = instrument.longMusicPlayer {
              VStack {
                Text(instrument.name)
                  .foregroundColor(.white)
                  .font(Font.system(size: 11))
                  .multilineTextAlignment(.leading)
                  .fixedSize()
                  .frame(height: 40, alignment: .center)
                Divider()
                Spacer()
                Text("Mute")
                  .foregroundColor(.white)
                  .font(Font.system(size: 11))

                Toggle(isOn: Binding(get: {instrument.isMuted}, set: { instrument.isMuted = $0 })) {
                  Text("Mute")
                }
                .labelsHidden()
                .onReceive(Just(instrument.isMuted)) { value in
                  instrument.isMuted = value
                  value ?
                    audioPlayer.setVolume(0.0, fadeDuration: 0.1)
                    : audioPlayer.setVolume(1.0, fadeDuration: 0.1)
                }
              }.frame(minWidth: 70, maxWidth: .infinity)
            }
            Divider()
          }
        }
      }
    }
      .padding(10)
      .background(BlurView(style: .systemUltraThinMaterialDark)
      .cornerRadius(12))
      .frame(height: 200)
      .padding(.horizontal, 20)

  }
}
