//
//  ClassicSoundView.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//


import SwiftUI
import ARKit
import PlaygroundSupport


public struct ClassicSoundView: View {
  @EnvironmentObject var ARSCNController: ARSCNViewControllerSimultaneous
  @State private var expandInfoMenu: Bool = false

  public init() { }

  public var body: some View {

    ARSCNViewBridged(sceneView: ARSCNController.sceneView)
      .ignoresSafeArea()
    // Act like a tap gesture
    .gesture(
      TapGesture()
        .onEnded({ _ in
        if ARSCNController.trackingState == .tapToStart {
          ARSCNController.startTap()
        }
      }))
    // When rotations or resizes of the view occur, .overlay performs better than the ZStack & .background
    .overlay(
      VStack(alignment: .center, spacing: 0) {
        HStack(alignment: .top) {
          SimultaneousSettingsView(ARSCNController: ARSCNController, expandMenu: $expandInfoMenu)
            .frame(width: 150)
          Spacer()
          BlurView(style: .systemUltraThinMaterialDark)
            .overlay(
            HStack {
              Text(ARSCNController.statusText)
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .multilineTextAlignment(.leading)
                .animation(.easeIn)
            }
          )
            .frame(height: 46)
            .cornerRadius(10)
        }.padding(10)

        Spacer()

        if (ARSCNController.trackingState == .started) {
          MixerView(ARSCNSimultaneous: ARSCNController)
        }
      }.transition(.opacity)
      , alignment: .top)

  }
}


