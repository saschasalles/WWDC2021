//
//  InstrumentSelector.swift
//  BookCore
//
//  Created by Sascha Sallès on 13/04/2021.
//

import Foundation
import SwiftUI

struct InstrumentSelectorView: View {
  @State private var enableAllBackground: Bool = true
  @State private var selection: Int = 0
  var body: some View {

    Picker(selection: $selection, label: Text("Instrument Picker")) {
      ForEach(0..<instruments.count) { index in
        Text(instruments[index].name).tag(index)
      }
    }
    .onReceive([self.selection].publisher.first()) { value in
      ARSCNViewControllerSingleSound.shared.selectInstrument(withName: instruments[selection].nodeName, identifier: instruments[selection].id)
    }
      .pickerStyle(SegmentedPickerStyle())
      .padding(30)
      .labelsHidden()
  }
}
