//
//  AdaptativeResultView.swift
//  BookCore
//
//  Created by Sascha Sallès on 19/04/2021.
//

import SwiftUI

struct AdaptativeResultView: View {
  var isGood: Bool
  var body: some View {
    HStack {
      Image(systemName: isGood ? "checkmark.circle.fill" : "xmark.circle.fill")
        .foregroundColor(.white)
        .font(.largeTitle)
      Text(isGood ? "Well Done 🎉" : "Oww that's a fail ☹️")
        .foregroundColor(.white)
    }
      .padding(30)
      .frame(height: 70)
      .background(isGood ? Color(.systemGreen) : Color(.systemOrange))
    .cornerRadius(12)
  }
}


