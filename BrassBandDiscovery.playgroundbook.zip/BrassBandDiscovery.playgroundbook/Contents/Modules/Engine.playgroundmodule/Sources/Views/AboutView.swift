//
//  AboutView.swift
//  BookCore
//
//  Created by Sascha Sallès on 18/04/2021.
//

import Foundation
import SwiftUI
import PlaygroundSupport

public struct AboutView: View {
  public init() {}
  public var body: some View {
    VStack {
      Text("About this playground")
        .font(.title)
        .foregroundColor(.white)
      Text("WWDC 2021")
        .font(.title2)
        .foregroundColor(.white)

      List {
        Section(header: Text("About Me")) {

          Text("Hello ! I'm Sascha Sallès, a French student who loves music and computers. Through this playground I wanted to introduce brass bands and their instruments. Musical culture is very important to me and today when I talk to people and show them an instrument, many of them don't know what it's called. Regarding my passion for computers, I have to be more precise. I have been passionate about Apple products since I was a child, and I decided to study iOS technologies. I think augmented reality is the best way to think about things in the real world. In these times of covid social interactions are limited and in my opinion AR allows us to transpose our own vision of things without any barrier. More info about me and my passion for Apple on saschasalles.com")
            .multilineTextAlignment(.leading)

        }

        Section(header: Text("Sources & Resources")) {
          Text("All 3D resources used are open and under creative-common license. I reworked all textures and shapes manually and optimized them for AR.")
            .multilineTextAlignment(.leading)
          Text("All the music assets are open and free. I found them on freewavesample.com")
            .multilineTextAlignment(.leading)
          Text("I composed the little brass music on GarageBand")
            .multilineTextAlignment(.leading)
        }
      }
      .listStyle(InsetGroupedListStyle())
    }.background(Color(.systemTeal).cornerRadius(12))
  }
}
