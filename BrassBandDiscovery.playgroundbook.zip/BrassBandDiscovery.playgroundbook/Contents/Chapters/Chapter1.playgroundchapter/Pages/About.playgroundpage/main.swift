//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import SwiftUI
import Engine
import UIKit


PlaygroundPage.current.setLiveView(AboutView())
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code

/*:
 ## WWDC 2021

 ### About Page


 > On this page you will find a SwiftUI view that summarizes the multiple sources used.

 */




