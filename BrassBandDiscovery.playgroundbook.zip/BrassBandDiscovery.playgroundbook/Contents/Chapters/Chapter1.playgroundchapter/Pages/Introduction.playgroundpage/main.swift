//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Engine


PlaygroundPage.current.setLiveView(WelcomeView())

//#-end-hidden-code



/*:
 ## WWDC 2021

 ### The brass band universe

 Hello 😀 I am Sascha Salles, a French computer science student based in Bordeaux 🍇🍷.
 This is my first contribution to the WWDC student challenge and I sincerely hope that you will appreciate it.
 Two great passions rhythm my days : iOS development 🍏 and music 🥁, and this playground represents the perfect symbiosis of its two passions.

 Through this playground I decided to make you discover the world of the brass band, a very rich field of music.
 To make the experience as interactive and lively as possible I decided to use augmented reality, and 3D with SceneKit.
 For the audio processing I used AVFoundation with AVAudioPlayer.
 And for the UI I used SwiftUI which gives unlimited freedom in terms of UI.
 I really hope you will enjoy this walk 🤗.



 > This playground uses Augmented Reality and needs camera access to function properly, it only works on iPad devices.


 > For the best experience, using the iPad in portrait mode is recommended even if the playground works on all orientations.

 Go to the [next page](@next) to discover the Brass Band Instruments !


 */
