//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import SwiftUI
import Engine
import UIKit



PlaygroundPage.current.setLiveView(QuizzView())
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true


//#-end-hidden-code

/*:
 ### The Brass Band Sound

 > Don't forget to activate the sound 🔊

 ### Check your skills

 Now is the time to test your knowledge!
 Perfect yourself, and have fun thanks to this little quiz created with SwiftUI


 Go to the [next page](@next) to know more about this playground 📖

 */


