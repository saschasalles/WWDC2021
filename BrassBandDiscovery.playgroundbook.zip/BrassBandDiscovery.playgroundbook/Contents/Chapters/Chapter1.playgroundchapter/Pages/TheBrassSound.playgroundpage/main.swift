//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import SwiftUI
import Engine
import UIKit



let vc = UIHostingController(rootView: ClassicSoundView().environmentObject(ARSCNViewControllerSimultaneous.shared))
PlaygroundPage.current.liveView = vc

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true


//#-end-hidden-code

/*:
 ### The Brass Band Sound


 > This playground uses Augmented Reality and needs camera access to function properly, it only works on iPad devices.

 > For the best experience, using the iPad in portrait mode is recommended even if the playground works on all orientations.

 > Don't forget to activate the sound 🔊

 ### Discover the brass sound

 So far we have only heard the instruments individually. We still haven't heard the sound of a brass band. I have composed especially for you a little music typical of an American brass band. You are free to use the mixer to switch or un-switch instruments :)

 Note that the instruments of the rhythm section answer each other and are a base for the accompanists which are the saxophone, the trumpet and the trombone.


 Go to the [next page](@next) to test what you have learned! ☑️
 */


