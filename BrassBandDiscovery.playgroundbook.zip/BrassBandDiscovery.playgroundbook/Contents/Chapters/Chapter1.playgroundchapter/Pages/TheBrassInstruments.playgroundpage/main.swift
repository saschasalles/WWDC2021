//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import SwiftUI
import Engine
import UIKit


let vc = UIHostingController(rootView: InstrumentView().environmentObject(ARSCNViewControllerSingleSound.shared))
PlaygroundPage.current.liveView = vc

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code

/*:
 ### The Brass Band Instruments


 > This playground uses Augmented Reality and needs camera access to function properly, it only works on iPad devices.

 > For the best experience, using the iPad in portrait mode is recommended even if the playground works on all orientations.

 > Don't forget to activate the sound 🔊

 ### Discover the brass instruments

 A brass band is a type of band that originated in New Orleans.
 It contains a large number of instruments and here are the most common ones.
 In this section you will learn more about the instruments that make up a brass band and their history.

 Touch each instrument to learn about it and to hear its sound.
 Let yourself be guided by the augmented reality instructions. Feel free to move around the instruments 😅


 Go to the [next page](@next) to discover the Brass Band Sounds !
 */



